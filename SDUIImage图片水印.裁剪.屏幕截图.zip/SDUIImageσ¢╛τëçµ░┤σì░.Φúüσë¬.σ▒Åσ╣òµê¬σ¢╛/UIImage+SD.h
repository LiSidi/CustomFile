//
//  UIImage+SD.h
//
//  Created by LSD on 15-9-25.
//  Copyright (c) 2015年 思娣. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (SD)

//打水印
+ (instancetype)waterImageWithBg:(NSString *)bg logo:(NSString *)logo;

//带边框颜色 的 图片裁剪 参数:图片名字. 边线宽度. 边界颜色
+ (instancetype)circleImageWithName:(NSString *)name borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)borderColor;

//屏幕截图
+ (instancetype)captureWithView:(UIView *)view;


@end
