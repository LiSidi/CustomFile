//
//  SDSearchBar.h
//  SDSina
//
//  Created by LSD on 15/10/31.
//  Copyright (c) 2015年 李思娣. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SDSearchBar : UITextField
+(instancetype)searchBar;
@end
