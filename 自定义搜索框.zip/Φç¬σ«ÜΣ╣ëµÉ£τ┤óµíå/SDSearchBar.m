//
//  SDSearchBar.m
//  SDSina
//
//  Created by LSD on 15/10/31.
//  Copyright (c) 2015年 李思娣. All rights reserved.
//

#import "SDSearchBar.h"

@implementation SDSearchBar
 /*---------自定义的搜索框--------*/
-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
       
        self.background = [UIImage resizableImage:@"searchbar_textfield_background"];
        //设置内容居中
        self.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        //设置左边的放大镜
        UIImageView *leftImage = [[UIImageView alloc] init];
        leftImage.image = [UIImage imageWithName:@"searchbar_textfield_search_icon"];
        //设置UIImageView的内容居中
        leftImage.contentMode = UIViewContentModeCenter;
        leftImage.width = leftImage.image.size.width + 10;
        leftImage.height = leftImage.image.size.height;
        
        self.leftView = leftImage;
        //设置左边的view永远显示
        self.leftViewMode = UITextFieldViewModeAlways;
        //设置右边永远显示清除按钮
        self.clearButtonMode = UITextFieldViewModeAlways;

    }
    return self;
}

+(instancetype)searchBar
{
    return [[self alloc]init];
}
@end
